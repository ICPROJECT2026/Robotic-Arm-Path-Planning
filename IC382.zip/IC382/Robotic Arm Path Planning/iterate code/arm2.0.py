import math
import random

class ArmPlannerPrototype:
    def __init__(self):
        # ========== Table rectangle geometry (X: length, Y: width) ==========
        self.table_length = 1800.0    # Table X direction (long side), mm
        self.table_width = 800.0   # Table Y direction (depth/width), mm
        # Arm base mounted at table frame: X = table_length / 2 , Y = 0
        self.arm_base_table_x = self.table_length / 2
        self.arm_base_table_y = 0.0

        # ========== 3 Planning Degrees‑of‑Freedom Limits ==========
        # DOF‑0: Base rotation (rotation joint, unit: degree)
        self.dof0_min = -360.0
        self.dof0_max = 360.0
        # DOF‑1: Upper‑arm swing rotation (rotation joint, unit: degree)
        self.dof1_min = -360.0
        self.dof1_max = 360.0
        # DOF‑2: End‑effector linear extension (prismatic joint, unit: mm)
        self.dof2_min = 350.0
        self.dof2_max = 600.0

        # Workspace defined in ARM‑BASE frame (mm), match DOF2 350‑600mm reach
        self.workspace_x_min = -650
        self.workspace_x_max = 650
        self.workspace_y_min = -650
        self.workspace_y_max = 650

        # Auxiliary vertical lift axis (NOT part of planning DOFs)
        self.lift_axis_retracted = True
        # Current joint state: [DOF0(deg), DOF1(deg), DOF2(mm)]
        self.current_joint = [0.0, 0.0, 0.0]

    def update_table_geometry(self, table_len: float, table_wid: float):
        """Update rectangular table length & width, recompute arm‑base position"""
        self.table_length = table_len
        self.table_width = table_wid
        self.arm_base_table_x = self.table_length / 2
        self.arm_base_table_y = 0.0

    def update_dof_limits(self, dof0_lim=None, dof1_lim=None, dof2_lim=None):
        """Update movement limits for each of the 3 planning degrees of freedom"""
        if dof0_lim is not None:
            self.dof0_min, self.dof0_max = dof0_lim
        if dof1_lim is not None:
            self.dof1_min, self.dof1_max = dof1_lim
        if dof2_lim is not None:
            self.dof2_min, self.dof2_max = dof2_lim

        print("\n==== Updated Degrees‑of‑Freedom Limits ====")
        print(f"DOF‑0 Base Rotation:   {self.dof0_min} ~ {self.dof0_max} °")
        print(f"DOF‑1 Upper‑arm Swing: {self.dof1_min} ~ {self.dof1_max} °")
        print(f"DOF‑2 Linear Extension:{self.dof2_min} ~ {self.dof2_max} mm")

    def table_to_arm_base(self, table_x: float, table_y: float):
        """
        Transform point from TABLE‑FRAME to ARM‑BASE‑FRAME
        Arm base position on rectangular table: (table_length/2 , 0)
        return (arm_x, arm_y)
        """
        arm_x = table_x - self.arm_base_table_x
        arm_y = table_y - self.arm_base_table_y
        return arm_x, arm_y

    def check_workspace(self, target_arm_x: float, target_arm_y: float):
        """Check whether target is inside arm planar workspace"""
        in_x = self.workspace_x_min <= target_arm_x <= self.workspace_x_max
        in_y = self.workspace_y_min <= target_arm_y <= self.workspace_y_max
        return in_x and in_y

    def simulate_inverse_kinematics(self, target_arm_x: float, target_arm_y: float):
        """
        Simulated inverse kinematics (logic prototype only)
        Input: target X,Y in arm‑base frame (mm)
        Return: (success_flag, [DOF0, DOF1, DOF2])
        """
        dx = target_arm_x
        dy = target_arm_y
        dof0_val = math.degrees(math.atan2(dy, dx))
        radial_dist = math.hypot(dx, dy)

        # Simulated mapping to DOF‑1 rotational joint
        dof1_val = min(max(radial_dist / 4.0, self.dof1_min), self.dof1_max)
        # Simulated mapping to DOF‑2 prismatic extension
        dof2_val = radial_dist * 0.65

        # Validate against each DOF hardware movement limit
        if not (self.dof0_min <= dof0_val <= self.dof0_max):
            return False, [dof0_val, dof1_val, dof2_val]
        if not (self.dof1_min <= dof1_val <= self.dof1_max):
            return False, [dof0_val, dof1_val, dof2_val]
        if not (self.dof2_min <= dof2_val <= self.dof2_max):
            return False, [dof0_val, dof1_val, dof2_val]

        return True, [dof0_val, dof1_val, dof2_val]

    def simulate_plan_trajectory(self, start_joint, target_joint):
        """
        Simulate motion trajectory interpolation
        Input: start and target [DOF0,DOF1,DOF2]
        Return: (plan_success, trajectory_waypoints)
        """
        trajectory_points = []
        step_count = 8
        for i in range(step_count + 1):
            ratio = i / step_count
            d0 = start_joint[0] + (target_joint[0] - start_joint[0]) * ratio
            d1 = start_joint[1] + (target_joint[1] - start_joint[1]) * ratio
            d2 = start_joint[2] + (target_joint[2] - start_joint[2]) * ratio
            trajectory_points.append([round(d0, 2), round(d1, 2), round(d2, 2)])

        # Simulate planning‑failure condition: near maximum extension of DOF‑2
        if target_joint[2] > self.dof2_max * 0.85:
            return False, trajectory_points
        return True, trajectory_points

    def execute_arm_task_table_coord(self, table_x, table_y, object_id="obj_test"):
        """
        Main mission entry: input target in TABLE‑FRAME coordinates
        Print how much each DOF needs to move.
        """
        print("=" * 65)
        print(f"[Mission Start] Object ID: {object_id}")
        print(f"Target in TABLE‑FRAME: X={table_x:.1f} mm , Y={table_y:.1f} mm")
        print(f"Table: Length(X) = {self.table_length:.1f} mm, Width(Y) = {self.table_width:.1f} mm")
        print(f"Arm‑base position on table: X={self.arm_base_table_x:.1f} mm, Y={self.arm_base_table_y:.1f} mm")

        arm_x, arm_y = self.table_to_arm_base(table_x, table_y)
        print(f"→ Converted to ARM‑BASE‑FRAME: arm_x={arm_x:.1f} mm, arm_y={arm_y:.1f} mm")
        print("[Status] Auxiliary lift axis stays retracted during arm movement")

        # Step1 workspace check
        if not self.check_workspace(arm_x, arm_y):
            print("[Fail] Target out of arm workspace, skip this object")
            return {"status": "skip", "object_id": object_id}

        # Step2 simulate inverse kinematics
        ik_success, target_joint = self.simulate_inverse_kinematics(arm_x, arm_y)
        t_d0, t_d1, t_d2 = target_joint
        print(f"\n[IK Result — Required movement for each DOF]")
        print(f"    DOF‑0 Base Rotation:      {t_d0:.2f} °")
        print(f"    DOF‑1 Upper‑arm Rotation:  {t_d1:.2f} °")
        print(f"    DOF‑2 Linear Extension:   {t_d2:.2f} mm")

        if not ik_success:
            print("[Fail] One or more DOF exceeds hardware movement limit, skip mission")
            return {"status": "ik_fail", "object_id": object_id}

        # Step3 simulate trajectory planning
        plan_success, traj = self.simulate_plan_trajectory(self.current_joint, target_joint)
        if not plan_success:
            print("[Fail] Planner detects potential collision, mark for manual review")
            return {"status": "plan_fail", "object_id": object_id}

        print(f"\n[Plan OK] Generated trajectory with {len(traj)} waypoints")
        for idx, pt in enumerate(traj):
            print(f"  Waypoint{idx:2d} | DOF0={pt[0]:6.2f}° | DOF1={pt[1]:6.2f}° | DOF2={pt[2]:6.2f}mm")

        # Step4 simulate physical movement of each DOF
        print("\n[Executing] Move each DOF along trajectory; lift axis remains retracted")
        self.current_joint = target_joint

        # Only trigger vertical lift axis after main 3‑DOF reach target pose
        print("[Reached target pose] → Activate auxiliary lift axis")
        self.lift_axis_retracted = False
        print("[Suction Cup Action] Release marker block")
        print("[Action Done] Retract auxiliary lift axis")
        self.lift_axis_retracted = True

        # Simulate post‑placement visual check
        if random.random() < 0.8:
            print("[Verification PASS] Marker placement completed")
            mission_status = "success"
        else:
            print("[Verification FAIL] Placement offset exceeds tolerance, mission failed")
            mission_status = "verify_fail"

        print(f"[Mission End] Final status: {mission_status}")
        return {"status": mission_status, "object_id": object_id, "final_joint": self.current_joint.copy()}


def main():
    planner = ArmPlannerPrototype()
    print("==== IC382 Robotic Arm Path‑Planning Logic Prototype ====")
    print("1: Manual input target point (TABLE‑FRAME X,Y mm)")
    print("2: Set movement limits for each DOF")
    print("3: Modify rectangular table: Length(X) & Width(Y)")
    print("q: quit program")

    while True:
        sel = input("\nPlease select mode (1/2/3/q): ")
        if sel == "q":
            break
        elif sel == "1":
            try:
                x_tbl = float(input("Input target TABLE‑FRAME X (mm): "))
                y_tbl = float(input("Input target TABLE‑FRAME Y (mm): "))
                oid = input("Object ID (press enter for default): ") or "obj_test"
                planner.execute_arm_task_table_coord(x_tbl, y_tbl, oid)
            except ValueError:
                print("Invalid numeric input!")
        elif sel == "2":
            print("\nSet movement limits for each DOF, press Enter to keep existing value")
            d0min = input(f"DOF‑0 min angle({planner.dof0_min}): ")
            d0max = input(f"DOF‑0 max angle({planner.dof0_max}): ")
            d1min = input(f"DOF‑1 min angle({planner.dof1_min}): ")
            d1max = input(f"DOF‑1 max angle({planner.dof1_max}): ")
            d2min = input(f"DOF‑2 min extension mm({planner.dof2_min}): ")
            d2max = input(f"DOF‑2 max extension mm({planner.dof2_max}): ")

            new_d0 = (float(d0min), float(d0max)) if (d0min and d0max) else None
            new_d1 = (float(d1min), float(d1max)) if (d1min and d1max) else None
            new_d2 = (float(d2min), float(d2max)) if (d2min and d2max) else None
            planner.update_dof_limits(new_d0, new_d1, new_d2)
        elif sel == "3":
            print(f"\nCurrent table: Length(X)={planner.table_length} mm, Width(Y)={planner.table_width} mm")
            new_len = input("New table Length (X, mm), Enter to skip: ")
            new_wid = input("New table Width (Y, mm), Enter to skip: ")
            l = planner.table_length
            w = planner.table_width
            if new_len.strip() != "":
                l = float(new_len)
            if new_wid.strip() != "":
                w = float(new_wid)
            planner.update_table_geometry(l, w)
            print(f"Updated: Length(X)={planner.table_length} mm, Width(Y)={planner.table_width} mm")
            print(f"Arm base on table at X={planner.arm_base_table_x:.1f} mm, Y={planner.arm_base_table_y:.1f} mm")
        else:
            print("Invalid option, try again.")


if __name__ == "__main__":
    main()

import cv2
import numpy as np

# =========================
# Global variables
# =========================
clicked_points = []          # For manual corner selection
calibrated_points = []       # Points to be converted to real coordinates
table_corners = None         # 4 corners of table in original image
H = None                     # Homography matrix
warp_width = 600             # Reduced for smoother performance
warp_height = 400
current_image = None
warped_table = None

# Max display/input image size to reduce lag
MAX_IMAGE_WIDTH = 960
MAX_IMAGE_HEIGHT = 540


# =========================
# Utility functions
# =========================
def resize_for_performance(image, max_w=960, max_h=540):
    h, w = image.shape[:2]
    scale = min(max_w / w, max_h / h, 1.0)
    new_w = int(w * scale)
    new_h = int(h * scale)
    resized = cv2.resize(image, (new_w, new_h))
    return resized


def safe_imshow(win_name, image, width=800, height=600):
    if image is None:
        print(f"[ERROR] Cannot display {win_name}: image is None")
        return
    cv2.namedWindow(win_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(win_name, width, height)
    cv2.imshow(win_name, image)
    cv2.waitKey(1)  # refresh GUI


def order_points(pts):
    pts = np.array(pts, dtype="float32")
    rect = np.zeros((4, 2), dtype="float32")

    s = pts.sum(axis=1)
    diff = np.diff(pts, axis=1)

    rect[0] = pts[np.argmin(s)]      # top-left
    rect[2] = pts[np.argmax(s)]      # bottom-right
    rect[1] = pts[np.argmin(diff)]   # top-right
    rect[3] = pts[np.argmax(diff)]   # bottom-left

    return rect


def compute_homography(corners, width=600, height=400):
    src = order_points(corners).astype(np.float32)
    dst = np.array([
        [0, 0],
        [width - 1, 0],
        [width - 1, height - 1],
        [0, height - 1]
    ], dtype=np.float32)

    H = cv2.getPerspectiveTransform(src, dst)
    return H


def warp_table_view(image, H, width=600, height=400):
    return cv2.warpPerspective(image, H, (width, height))


def draw_table_edges(image, corners):
    img = image.copy()
    corners = order_points(corners).astype(int)

    for i in range(4):
        pt1 = tuple(corners[i])
        pt2 = tuple(corners[(i + 1) % 4])
        cv2.line(img, pt1, pt2, (0, 255, 0), 2)

    for i, p in enumerate(corners):
        cv2.circle(img, tuple(p), 5, (0, 0, 255), -1)
        cv2.putText(img, f"{i+1}", (p[0] + 8, p[1] + 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

    return img


# =========================
# Automatic table detection
# =========================
def detect_table_corners(frame):
    print("[INFO] Starting automatic table detection...")

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    edges = cv2.Canny(blur, 80, 180)

    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    best_quad = None
    best_area = 0

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < 3000:
            continue

        peri = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)

        if len(approx) == 4 and area > best_area:
            best_area = area
            best_quad = approx.reshape(4, 2)

    if best_quad is not None:
        print("[INFO] Table detected.")
        return order_points(best_quad)

    print("[WARNING] Automatic detection failed.")
    return None


# =========================
# Manual point selection
# =========================
def mouse_callback(event, x, y, flags, param):
    global clicked_points

    if event == cv2.EVENT_LBUTTONDOWN:
        if len(clicked_points) < 4:
            clicked_points.append((x, y))
            print(f"[INFO] Point {len(clicked_points)} selected: ({x}, {y})")


def manual_select_corners(image):
    global clicked_points

    clicked_points = []
    temp = image.copy()

    cv2.namedWindow("Manual Select 4 Corners", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("Manual Select 4 Corners", 900, 650)
    cv2.setMouseCallback("Manual Select 4 Corners", mouse_callback)

    print("[INFO] Click 4 corners, then press ENTER. Press ESC to cancel.")

    while True:
        display = temp.copy()

        for i, pt in enumerate(clicked_points):
            cv2.circle(display, pt, 5, (0, 0, 255), -1)
            cv2.putText(display, f"{i+1}", (pt[0] + 10, pt[1] + 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

        cv2.imshow("Manual Select 4 Corners", display)
        key = cv2.waitKey(20) & 0xFF

        if key == 13 and len(clicked_points) == 4:  # Enter
            break
        elif key == 27:  # ESC
            clicked_points = []
            break

    cv2.destroyWindow("Manual Select 4 Corners")

    if len(clicked_points) == 4:
        return order_points(clicked_points)
    return None


# =========================
# Insert image onto table
# =========================
def insert_image_into_table(insert_img_path):
    insert_img = cv2.imread(insert_img_path)
    if insert_img is None:
        print("[ERROR] Failed to load insert image.")
        return None

    insert_img = resize_for_performance(insert_img, warp_width, warp_height)
    insert_resized = cv2.resize(insert_img, (warp_width, warp_height))
    return insert_resized


# =========================
# Real coordinate conversion
# =========================
def convert_points_to_real_coords(image_points, H, warp_width, warp_height, real_width, real_height):
    pts = np.array(image_points, dtype=np.float32).reshape(-1, 1, 2)
    warped_pts = cv2.perspectiveTransform(pts, H).reshape(-1, 2)

    real_points = []
    for (x, y) in warped_pts:
        real_x = (x / warp_width) * real_width
        real_y = (y / warp_height) * real_height
        real_points.append((real_x, real_y))

    return warped_pts, real_points


# =========================
# Add calibration points manually
# =========================
def add_calibration_points():
    global calibrated_points

    print("\nEnter calibrated points one by one.")
    print("Format: x y")
    print("Type 'q' to stop.\n")

    while True:
        user_input = input("Enter point (x y) or q: ").strip()
        if user_input.lower() == 'q':
            break
        try:
            x, y = map(float, user_input.split())
            calibrated_points.append((x, y))
            print(f"[INFO] Added point: ({x}, {y})")
        except:
            print("[WARNING] Invalid input. Please enter in format: x y")


# =========================
# Load image helper
# =========================
def load_image_from_path():
    image_path = input("Enter image path: ").strip()
    image = cv2.imread(image_path)

    if image is None:
        print("[ERROR] Failed to load image.")
        return None

    image = resize_for_performance(image, MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT)
    print(f"[INFO] Loaded image with size: {image.shape[1]}x{image.shape[0]}")
    return image


# =========================
# Camera capture helper
# =========================
def capture_from_camera():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("[ERROR] Cannot open camera.")
        return None

    print("[INFO] Press SPACE to capture image, ESC to cancel.")

    captured = None
    while True:
        ret, frame = cap.read()
        if not ret:
            print("[ERROR] Failed to read camera frame.")
            break

        frame = resize_for_performance(frame, MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT)
        cv2.imshow("Camera", frame)
        key = cv2.waitKey(20) & 0xFF

        if key == 32:  # Space
            captured = frame.copy()
            print("[INFO] Image captured.")
            break
        elif key == 27:  # ESC
            break

    cap.release()
    cv2.destroyWindow("Camera")
    return captured


# =========================
# Main program
# =========================
def main():
    global table_corners, H, warped_table

    print("Choose input mode:")
    print("1 = Manual positioning")
    print("2 = Automatic positioning")
    print("3 = Capture image from camera")
    print("4 = Import photo")

    mode = input("Enter mode (1/2/3/4): ").strip()

    image = None

    if mode == '3':
        image = capture_from_camera()
        if image is None:
            print("[ERROR] No image captured.")
            return

        # For camera mode, ask manual or auto corner detection
        detect_mode = input("Corner detection: 1 = manual, 2 = automatic: ").strip()
        if detect_mode == '1':
            table_corners = manual_select_corners(image)
        else:
            table_corners = detect_table_corners(image)

    elif mode == '1':
        image = load_image_from_path()
        if image is None:
            return
        table_corners = manual_select_corners(image)

    elif mode == '2':
        image = load_image_from_path()
        if image is None:
            return
        table_corners = detect_table_corners(image)

    elif mode == '4':
        image = load_image_from_path()
        if image is None:
            return
        detect_mode = input("Corner detection: 1 = manual, 2 = automatic: ").strip()
        if detect_mode == '1':
            table_corners = manual_select_corners(image)
        else:
            table_corners = detect_table_corners(image)

    else:
        print("[ERROR] Invalid mode.")
        return

    if table_corners is None:
        print("[ERROR] Table corner detection/selection failed.")
        return

    print("[INFO] Table corners:")
    print(table_corners)

    print("[INFO] Computing homography...")
    H = compute_homography(table_corners, warp_width, warp_height)

    print("[INFO] Warping table...")
    warped_table = warp_table_view(image, H, warp_width, warp_height)

    edge_img = draw_table_edges(image, table_corners)

    safe_imshow("Detected Table Edges", edge_img, 800, 600)
    safe_imshow("Warped Table", warped_table, 800, 600)

    print("[INFO] Windows displayed successfully.")

    # Command loop
    while True:
        print("\nCommands:")
        print("a = add calibrated points")
        print("i = insert image onto table")
        print("r = convert calibrated points to real coordinates")
        print("q = quit")

        command = input("Enter command: ").strip().lower()

        if command == 'a':
            add_calibration_points()

        elif command == 'i':
            insert_path = input("Enter image path to insert: ").strip()
            inserted = insert_image_into_table(insert_path)
            if inserted is not None:
                safe_imshow("Inserted Image on Table", inserted, 800, 600)
                print("[INFO] Inserted image displayed.")

        elif command == 'r':
            if len(calibrated_points) == 0:
                print("[WARNING] No calibrated points available.")
                continue

            if H is None:
                print("[ERROR] Homography not available.")
                continue

            try:
                real_width = float(input("Enter real table width (cm): "))
                real_height = float(input("Enter real table height (cm): "))

                warped_pts, real_points = convert_points_to_real_coords(
                    calibrated_points, H, warp_width, warp_height, real_width, real_height
                )

                print("\nConverted real coordinates:")
                for i, ((wx, wy), (rx, ry)) in enumerate(zip(warped_pts, real_points)):
                    print(f"Point {i+1}: warped=({wx:.2f}, {wy:.2f}) -> real=({rx:.2f} cm, {ry:.2f} cm)")

            except:
                print("[WARNING] Invalid table size input.")

        elif command == 'q':
            break

        else:
            print("[WARNING] Unknown command.")

    cv2.destroyAllWindows()
    print("[INFO] Program ended.")


if __name__ == "__main__":
    main()

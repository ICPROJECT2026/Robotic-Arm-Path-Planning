import cv2
import numpy as np
import matplotlib.pyplot as plt

# 读取深度图
depth = cv2.imread("depth.png", cv2.IMREAD_UNCHANGED)

if depth is None:
    print("没读到 depth.png")
else:
    print("shape:", depth.shape)
    print("dtype:", depth.dtype)
    print("min:", np.min(depth))
    print("max:", np.max(depth))

    plt.figure(figsize=(10, 4))

    plt.subplot(1, 2, 1)
    if len(depth.shape) == 2:
        plt.imshow(depth, cmap="gray")
    else:
        depth_gray = cv2.cvtColor(depth, cv2.COLOR_BGR2GRAY)
        plt.imshow(depth_gray, cmap="gray")
    plt.title("Gray")
    plt.axis("off")

    plt.subplot(1, 2, 2)
    if len(depth.shape) == 2:
        plt.imshow(depth, cmap="jet")
    else:
        depth_gray = cv2.cvtColor(depth, cv2.COLOR_BGR2GRAY)
        plt.imshow(depth_gray, cmap="jet")
    plt.title("Jet")
    plt.axis("off")

    plt.tight_layout()
    plt.show()

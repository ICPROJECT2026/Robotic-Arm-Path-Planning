import numpy as np
import cv2
import matplotlib.pyplot as plt

# 创建一张 480x640 的 RGB 图
h, w = 480, 640
img = np.zeros((h, w, 3), dtype=np.uint8)

# 红色通道：横向渐变
for x in range(w):
    img[:, x, 0] = int(255 * x / w)

# 绿色通道：纵向渐变
for y in range(h):
    img[y, :, 1] = int(255 * y / h)

# 蓝色通道：固定值
img[:, :, 2] = 120

# 添加几个彩色矩形，方便观察
cv2.rectangle(img, (50, 50), (200, 200), (255, 0, 0), -1)   # 红色块
cv2.rectangle(img, (250, 100), (400, 250), (0, 255, 0), -1) # 绿色块
cv2.rectangle(img, (450, 150), (600, 300), (0, 0, 255), -1) # 蓝色块

# 添加一个圆
cv2.circle(img, (320, 380), 60, (255, 255, 0), -1)  # 青色圆

# 保存图片
cv2.imwrite("fake_rgb.png", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))

# 显示图片
plt.imshow(img)
plt.title("Fake RGB Image")
plt.axis("off")
plt.show()

import cv2
import matplotlib.pyplot as plt

# 读取 RGB 图
rgb = cv2.imread("rgb.jpg")

# 用原始方式读取第二张图
depth = cv2.imread("depth.png", cv2.IMREAD_UNCHANGED)

if rgb is None:
    print("没读到 rgb.jpg")
elif depth is None:
    print("没读到 depth.png")
else:
    print("rgb shape:", rgb.shape)
    print("depth shape:", depth.shape)
    print("depth dtype:", depth.dtype)

    rgb_show = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)

    plt.figure(figsize=(12, 4))

    # 1. RGB
    plt.subplot(1, 3, 1)
    plt.imshow(rgb_show)
    plt.title("RGB")
    plt.axis("off")

    # 2. 第二张图灰度显示
    plt.subplot(1, 3, 2)
    if len(depth.shape) == 2:
        plt.imshow(depth, cmap="gray")
    else:
        depth_gray = cv2.cvtColor(depth, cv2.COLOR_BGR2GRAY)
        plt.imshow(depth_gray, cmap="gray")
    plt.title("Depth Gray Style")
    plt.axis("off")

    # 3. 第二张图伪彩色显示
    plt.subplot(1, 3, 3)
    if len(depth.shape) == 2:
        plt.imshow(depth, cmap="jet")
    else:
        depth_gray = cv2.cvtColor(depth, cv2.COLOR_BGR2GRAY)
        plt.imshow(depth_gray, cmap="jet")
    plt.title("Depth Color Style")
    plt.axis("off")

    plt.tight_layout()
    plt.show()

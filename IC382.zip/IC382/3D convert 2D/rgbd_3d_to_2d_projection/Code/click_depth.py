import cv2
import matplotlib.pyplot as plt

# 读取 RGB 和 depth
rgb = cv2.imread("rgb.jpg")
depth = cv2.imread("fake_depth.png", cv2.IMREAD_UNCHANGED)

if rgb is None:
    print("没读到 rgb.jpg")
elif depth is None:
    print("没读到 fake_depth.png")
else:
    rgb_show = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].imshow(rgb_show)
    axes[0].set_title("RGB")
    axes[0].axis("off")

    axes[1].imshow(depth, cmap="jet")
    axes[1].set_title("Click Depth Image")
    axes[1].axis("off")

    def onclick(event):
        if event.inaxes == axes[1] and event.xdata is not None and event.ydata is not None:
            x = int(event.xdata)
            y = int(event.ydata)

            value = depth[y, x]
            print(f"你点的位置: x={x}, y={y}, depth={value}")

    fig.canvas.mpl_connect("button_press_event", onclick)
    plt.tight_layout()
    plt.show()

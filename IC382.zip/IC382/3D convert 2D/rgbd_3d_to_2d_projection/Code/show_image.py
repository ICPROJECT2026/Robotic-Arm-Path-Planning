import os
import cv2
import matplotlib.pyplot as plt

print("当前工作文件夹：", os.getcwd())

img = cv2.imread("test.jpg")

if img is None:
    print("图片没读到，请检查 test.jpg 是否在同一个文件夹里")
else:
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    plt.imshow(img_rgb)
    plt.title("My First Image")
    plt.axis("off")
    plt.show()
